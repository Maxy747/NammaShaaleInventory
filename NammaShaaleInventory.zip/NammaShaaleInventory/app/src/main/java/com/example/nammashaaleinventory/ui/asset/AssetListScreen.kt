package com.example.nammashaaleinventory.ui.asset

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.nammashaaleinventory.data.AssetEntity
import com.example.nammashaaleinventory.ui.AppViewModelProvider
import com.example.nammashaaleinventory.ui.home.DashboardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetListScreen(
    navigateBack: () -> Unit,
    navigateToAssetDetail: (Int) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val assetList by viewModel.allAssets.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Assets") },
                navigationIcon = {
                    IconButton(onClick = navigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .padding(innerPadding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items = assetList, key = { it.id }) { asset ->
                AssetItem(
                    asset = asset,
                    modifier = Modifier.clickable { navigateToAssetDetail(asset.id) }
                )
            }
        }
    }
}

@Composable
fun AssetItem(asset: AssetEntity, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = asset.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Category: ${asset.category}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = asset.condition,
                    style = MaterialTheme.typography.bodyMedium,
                    color = when(asset.condition) {
                        "Working" -> MaterialTheme.colorScheme.primary
                        "Broken" -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.tertiary
                    },
                    fontWeight = FontWeight.Bold
                )
            }
            if (asset.qrCodeHash.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "QR Tag: ${asset.qrCodeHash}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}
