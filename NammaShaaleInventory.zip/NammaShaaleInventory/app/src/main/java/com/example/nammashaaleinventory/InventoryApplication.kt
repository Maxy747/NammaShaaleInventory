package com.example.nammashaaleinventory

import android.app.Application
import com.example.nammashaaleinventory.data.AppContainer
import com.example.nammashaaleinventory.data.AppDataContainer

class InventoryApplication : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppDataContainer(this)
    }
}
