package com.example.nammashaaleinventory.data

import kotlinx.coroutines.flow.Flow

class InventoryRepository(private val assetDao: AssetDao) {
    fun getAllAssets(): Flow<List<AssetEntity>> = assetDao.getAllAssets()
    
    fun getAssetByIdStream(id: Int): Flow<AssetEntity?> = assetDao.getAssetByIdFlow(id)

    suspend fun getAssetByQrCode(qrCodeHash: String): AssetEntity? = assetDao.getAssetByQrCode(qrCodeHash)

    suspend fun insertAsset(asset: AssetEntity) = assetDao.insertAsset(asset)

    suspend fun updateAsset(asset: AssetEntity) = assetDao.updateAsset(asset)

    suspend fun deleteAsset(asset: AssetEntity) = assetDao.deleteAsset(asset)
    
    fun getTotalAssetsCount(): Flow<Int> = assetDao.getTotalAssetsCount()
    
    fun getBrokenAssetsCount(): Flow<Int> = assetDao.getBrokenAssetsCount()
    
    fun getRepairAssetsCount(): Flow<Int> = assetDao.getRepairAssetsCount()
}
