package com.example.nammashaaleinventory.ui.asset

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.nammashaaleinventory.ui.AppViewModelProvider
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetDetailScreen(
    assetId: Int,
    qrCode: String?,
    navigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AssetDetailViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val coroutineScope = rememberCoroutineScope()
    
    LaunchedEffect(assetId, qrCode) {
        if (assetId > 0) {
            viewModel.loadAsset(assetId)
        } else if (!qrCode.isNullOrEmpty()) {
            viewModel.loadAssetByQr(qrCode)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (assetId > 0) "Edit Asset" else "Add Asset") },
                navigationIcon = {
                    IconButton(onClick = navigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        AssetEntryBody(
            assetUiState = viewModel.uiState,
            onAssetValueChange = viewModel::updateUiState,
            onSaveClick = {
                coroutineScope.launch {
                    viewModel.saveAsset()
                    navigateBack()
                }
            },
            modifier = modifier
                .padding(innerPadding)
                .fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetEntryBody(
    assetUiState: AssetUiState,
    onAssetValueChange: (AssetUiState) -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        OutlinedTextField(
            value = assetUiState.name,
            onValueChange = { onAssetValueChange(assetUiState.copy(name = it)) },
            label = { Text("Asset Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        
        OutlinedTextField(
            value = assetUiState.category,
            onValueChange = { onAssetValueChange(assetUiState.copy(category = it)) },
            label = { Text("Category (Tablet, Furniture, Lab Tool)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        var expanded by remember { mutableStateOf(false) }
        val conditions = listOf("Working", "Broken", "Repair")
        
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                value = assetUiState.condition,
                onValueChange = {},
                readOnly = true,
                label = { Text("Condition") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                conditions.forEach { condition ->
                    DropdownMenuItem(
                        text = { Text(condition) },
                        onClick = {
                            onAssetValueChange(assetUiState.copy(condition = condition))
                            expanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = assetUiState.qrCodeHash,
            onValueChange = { onAssetValueChange(assetUiState.copy(qrCodeHash = it)) },
            label = { Text("QR Code Hash") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(
            onClick = onSaveClick,
            enabled = assetUiState.actionEnabled,
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp)
        ) {
            Text("Save Asset")
        }
    }
}
