package com.example.nammashaaleinventory.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.nammashaaleinventory.ui.asset.AssetDetailScreen
import com.example.nammashaaleinventory.ui.asset.AssetListScreen
import com.example.nammashaaleinventory.ui.home.DashboardScreen
import com.example.nammashaaleinventory.ui.scanner.ScannerScreen

enum class InventoryDestinations(val route: String) {
    Dashboard("dashboard"),
    AssetList("asset_list"),
    AssetDetail("asset_detail/{assetId}?qrCode={qrCode}"),
    Scanner("scanner")
}

@Composable
fun InventoryNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = InventoryDestinations.Dashboard.route,
        modifier = modifier
    ) {
        composable(route = InventoryDestinations.Dashboard.route) {
            DashboardScreen(
                navigateToAssetList = { navController.navigate(InventoryDestinations.AssetList.route) },
                navigateToScanner = { navController.navigate(InventoryDestinations.Scanner.route) },
                navigateToAssetDetail = { assetId -> 
                    navController.navigate(InventoryDestinations.AssetDetail.route.replace("{assetId}", assetId.toString()).replace("?qrCode={qrCode}", "")) 
                }
            )
        }
        
        composable(route = InventoryDestinations.AssetList.route) {
            AssetListScreen(
                navigateBack = { navController.popBackStack() },
                navigateToAssetDetail = { assetId ->
                    navController.navigate(InventoryDestinations.AssetDetail.route.replace("{assetId}", assetId.toString()).replace("?qrCode={qrCode}", ""))
                }
            )
        }
        
        composable(
            route = InventoryDestinations.AssetDetail.route,
            arguments = listOf(
                navArgument("assetId") { type = NavType.IntType },
                navArgument("qrCode") { 
                    type = NavType.StringType 
                    nullable = true 
                    defaultValue = null 
                }
            )
        ) { backStackEntry ->
            val assetId = backStackEntry.arguments?.getInt("assetId") ?: 0
            val qrCode = backStackEntry.arguments?.getString("qrCode")
            AssetDetailScreen(
                assetId = assetId,
                qrCode = qrCode,
                navigateBack = { navController.popBackStack() }
            )
        }
        
        composable(route = InventoryDestinations.Scanner.route) {
            ScannerScreen(
                navigateBack = { navController.popBackStack() },
                onQrCodeScanned = { qrCode ->
                    // Navigate to asset detail. We pass 0 for ID and append the qrCode query param
                    navController.navigate("asset_detail/0?qrCode=$qrCode") {
                        popUpTo(InventoryDestinations.Scanner.route) { inclusive = true }
                    }
                }
            )
        }
    }
}
