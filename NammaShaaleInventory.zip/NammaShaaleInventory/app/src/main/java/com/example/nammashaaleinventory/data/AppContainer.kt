package com.example.nammashaaleinventory.data

import android.content.Context

interface AppContainer {
    val inventoryRepository: InventoryRepository
}

class AppDataContainer(private val context: Context) : AppContainer {
    override val inventoryRepository: InventoryRepository by lazy {
        InventoryRepository(AppDatabase.getDatabase(context).assetDao())
    }
}
