package com.example.nammashaaleinventory.ui

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.nammashaaleinventory.InventoryApplication
import com.example.nammashaaleinventory.ui.asset.AssetDetailViewModel
import com.example.nammashaaleinventory.ui.home.DashboardViewModel

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            DashboardViewModel(
                inventoryApplication().container.inventoryRepository
            )
        }
        initializer {
            AssetDetailViewModel(
                inventoryApplication().container.inventoryRepository
            )
        }
    }
}

fun CreationExtras.inventoryApplication(): InventoryApplication =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as InventoryApplication)
