package com.example.nammashaaleinventory.ui.asset

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nammashaaleinventory.data.AssetEntity
import com.example.nammashaaleinventory.data.InventoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class AssetDetailViewModel(private val repository: InventoryRepository) : ViewModel() {

    var uiState by mutableStateOf(AssetUiState())
        private set

    fun updateUiState(newAssetUiState: AssetUiState) {
        uiState = newAssetUiState.copy(actionEnabled = newAssetUiState.isValid())
    }

    suspend fun saveAsset() {
        if (uiState.isValid()) {
            val asset = uiState.toAssetEntity()
            if (asset.id == 0) {
                repository.insertAsset(asset)
            } else {
                repository.updateAsset(asset)
            }
        }
    }

    fun loadAsset(assetId: Int) {
        viewModelScope.launch {
            val asset = repository.getAssetByIdStream(assetId).firstOrNull()
            if (asset != null) {
                uiState = asset.toAssetUiState(actionEnabled = true)
            }
        }
    }

    fun loadAssetByQr(qrCode: String) {
        viewModelScope.launch {
            val asset = repository.getAssetByQrCode(qrCode)
            if (asset != null) {
                uiState = asset.toAssetUiState(actionEnabled = true)
            } else {
                // Pre-fill a new asset with this QR code
                uiState = AssetUiState(qrCodeHash = qrCode)
            }
        }
    }
}

data class AssetUiState(
    val id: Int = 0,
    val name: String = "",
    val category: String = "Tablet",
    val condition: String = "Working",
    val qrCodeHash: String = "",
    val actionEnabled: Boolean = false
)

fun AssetUiState.isValid(): Boolean {
    return name.isNotBlank() && category.isNotBlank() && condition.isNotBlank()
}

fun AssetUiState.toAssetEntity(): AssetEntity = AssetEntity(
    id = id,
    name = name,
    category = category,
    condition = condition,
    qrCodeHash = qrCodeHash,
    lastAuditDate = System.currentTimeMillis()
)

fun AssetEntity.toAssetUiState(actionEnabled: Boolean = false): AssetUiState = AssetUiState(
    id = id,
    name = name,
    category = category,
    condition = condition,
    qrCodeHash = qrCodeHash,
    actionEnabled = actionEnabled
)
