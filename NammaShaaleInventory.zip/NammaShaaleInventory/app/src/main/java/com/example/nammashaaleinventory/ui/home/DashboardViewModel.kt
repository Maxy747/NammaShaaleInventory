package com.example.nammashaaleinventory.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nammashaaleinventory.data.AssetEntity
import com.example.nammashaaleinventory.data.InventoryRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(private val repository: InventoryRepository) : ViewModel() {
    
    val totalAssetsCount: StateFlow<Int> = repository.getTotalAssetsCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
        
    val brokenAssetsCount: StateFlow<Int> = repository.getBrokenAssetsCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
        
    val repairAssetsCount: StateFlow<Int> = repository.getRepairAssetsCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val allAssets: StateFlow<List<AssetEntity>> = repository.getAllAssets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
